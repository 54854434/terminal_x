/// Fail-closed trading service. Private market calculations are isolated from
/// the UI; only SQLite-committed revisions become visible or actionable.
import 'dart:isolate';

import '../engine/tx_engine.dart';
import '../engine/tx_session.dart';
import '../market/tx_market_event_tape.dart';
import 'tx_persistent_market_worker.dart';
import 'tx_sqlite_store.dart';

TxSession _advanceMinute(TxSession session) {
  session.nextTick();
  return session;
}

class _TradeProposal {
  const _TradeProposal(this.session, this.orderId);
  final TxSession session;
  final String orderId;
}

_TradeProposal _placeOnWorker(
    TxSession original, String symbol, TxSide side, TxKind kind,
    int quantity, int? limitPriceCents) {
  final proposed = TxSession.importJson(original.exportJson());
  final order = proposed.placePlayer(
    symbol: symbol, side: side, kind: kind, quantity: quantity,
    limitPriceCents: limitPriceCents);
  return _TradeProposal(proposed, order.id);
}

_TradeProposal _cancelOnWorker(TxSession original, String orderId) {
  final proposed = TxSession.importJson(original.exportJson());
  final order = proposed.cancelPlayer(orderId);
  return _TradeProposal(proposed, order.id);
}

class TxTradingService {
  TxTradingService(this.database, {TxSession Function()? initialSessionFactory,
      this.persistentMarketWorker = false})
      : _initialSessionFactory = initialSessionFactory ?? TxSession.fresh;

  final TxSqliteStore database;
  final TxSession Function() _initialSessionFactory;
  /// Opt-in to a single long-lived isolate. Default retains original service
  /// semantics for older tests, embedders and in-memory database fixtures.
  final bool persistentMarketWorker;
  TxPersistentMarketWorker? _worker;
  TxStoredSession? _current;
  bool _busy = false;
  bool _storageFault = false;

  TxStoredSession get current {
    if (_current == null) throw StateError('SQLite session not initialized');
    return _current!;
  }

  bool get blocked => _storageFault;

  Future<TxStoredSession> open() async {
    if (_current != null) return current;
    if (_busy) throw StateError('Storage is busy');
    _busy = true;
    try {
      final loaded = await database.readCurrent() ??
          await database.initializeFresh(_initialSessionFactory());
      if (persistentMarketWorker) {
        _worker = await TxPersistentMarketWorker.start(loaded.session);
      }
      _current = loaded;
      return loaded;
    } catch (_) {
      _storageFault = true;
      _worker?.close();
      _worker = null;
      rethrow;
    } finally {
      _busy = false;
    }
  }

  Future<TxOrder> place({
    required String symbol,
    required TxSide side,
    required TxKind kind,
    required int quantity,
    int? limitPriceCents,
  }) async {
    _ensureReady();
    _busy = true;
    try {
      if (_worker != null) {
        final proposal = await _worker!.place(
          symbol: symbol, side: side, kind: kind,
          quantity: quantity, limitPriceCents: limitPriceCents);
        await _commit(proposal.session);
        await _ackWorkerCommit();
        return current.session.engine.order(proposal.orderId!);
      }
      final source = current.session;
      final proposal = await Isolate.run(() => _placeOnWorker(
        source, symbol, side, kind, quantity, limitPriceCents));
      await _commit(proposal.session);
      return current.session.engine.order(proposal.orderId);
    } catch (_) {
      // Invalid user orders must not poison an otherwise valid account.
      // Discard any uncommitted worker state and reinitialize from the exact
      // last committed revision. A genuine storage failure remains blocked.
      await _restoreWorkerAfterRejectedAction();
      rethrow;
    } finally {
      _busy = false;
    }
  }

  Future<TxOrder> cancel(String orderId) async {
    _ensureReady();
    _busy = true;
    try {
      if (_worker != null) {
        final proposal = await _worker!.cancel(orderId);
        await _commit(proposal.session);
        await _ackWorkerCommit();
        return current.session.engine.order(proposal.orderId!);
      }
      final source = current.session;
      final proposal = await Isolate.run(() => _cancelOnWorker(source, orderId));
      await _commit(proposal.session);
      return current.session.engine.order(proposal.orderId);
    } catch (_) {
      await _restoreWorkerAfterRejectedAction();
      rethrow;
    } finally {
      _busy = false;
    }
  }

  Future<TxMinuteEventTape> nextTickWithTape() async {
    final before = current;
    final after = await nextTick();
    return TxMinuteEventTape.fromCommits(before, after);
  }

  Future<TxStoredSession> nextTick() async {
    _ensureReady();
    _busy = true;
    try {
      final candidate = _worker != null
          ? (await _worker!.tick()).session
          : await Isolate.run(() => _advanceMinute(current.session));
      await _commit(candidate);
      await _ackWorkerCommit();
      return current;
    } catch (_) {
      if (_worker != null) {
        _worker!.close();
        _worker = null;
        _storageFault = true;
      }
      rethrow;
    } finally {
      _busy = false;
    }
  }

  Future<void> _ackWorkerCommit() async {
    final worker = _worker;
    if (worker == null) return;
    try {
      await worker.acknowledgeCommitted();
    } catch (_) {
      // SQLite has already committed; recover the worker from the exact
      // committed UI mirror, never retry the trade or duplicate an order.
      worker.close();
      _worker = null;
      try {
        _worker = await TxPersistentMarketWorker.start(current.session);
      } catch (_) {
        _storageFault = true;
        rethrow;
      }
    }
  }

  Future<void> _restoreWorkerAfterRejectedAction() async {
    final stale = _worker;
    if (stale == null) return;
    stale.close();
    _worker = null;
    if (_storageFault) return;
    try {
      _worker = await TxPersistentMarketWorker.start(current.session);
    } catch (_) {
      _storageFault = true;
      rethrow;
    }
  }

  void _ensureReady() {
    if (_storageFault) {
      throw StateError('SQLite storage error: reopen and verify before trading');
    }
    if (_busy) throw StateError('A save is already in progress');
    if (_current == null) throw StateError('Session has not loaded');
  }

  Future<void> _commit(TxSession candidate) async {
    try {
      final saved = await database.saveSession(
        candidate, expectedRevision: current.revision,
      );
      _current = saved;
    } catch (_) {
      _storageFault = true;
      rethrow;
    }
  }

  Future<void> close() async {
    _worker?.close();
    _worker = null;
    await database.close();
  }
}
