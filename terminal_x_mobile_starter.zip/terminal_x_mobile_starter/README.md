# Terminal X mobile starter

Android-only offline prototype for GitHub Actions builds from a phone browser.

Contents:
- `pubspec.yaml`
- `lib/main.dart`
- `.github/workflows/build-apk.yml`

On GitHub create a *private* repository named `terminal_x`. Upload these files preserving their directory paths. In Actions open **Build Android APK**, run workflow (or push a commit). Download artifact `terminal-x-android-debug`, unzip if needed, then install `app-debug.apk` on Android.

GitHub Actions generates platform files using `flutter create --project-name terminal_x --platforms=android .` before building, so no laptop SDK is needed.

This is an intentionally limited feasibility prototype, not the completed V0.1 engine: quotes are synthetic, pending orders have simplified semantics, no money reservation, no proper order book, no trading calendar and no candle chart. Do not rely on it for investing.

Debug APK signing keys may differ between CI runs: uninstall/reinstall can be needed for the next version (which deletes app data). For durable updates, configure a stable private release keystore stored in GitHub Actions secrets and implement backup/export first.
